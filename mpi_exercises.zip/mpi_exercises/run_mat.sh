#!/bin/bash

# Get the maximum number of cores
# max_cores=$(grep -c ^processor /proc/cpuinfo)
max_cores=4

# Matrix dimensions to iterate over
dimensions=(80 800 8000)

# Function to check if a number is a power of 2
is_power_of_2() {
    return $(($1 & ($1 - 1)))
}


# Loop through 1 to max_cores to find powers of 2
for ((p=1; p<=max_cores; p++)); do
    # Loop through the dimensions
    for m in "${dimensions[@]}"; do
        if is_power_of_2 $p; then
            echo "Running with $p processes, Matrix dimensions: $m x $m"
            # Execute the MPI program
            mpirun -np $p ./aux $m $n
        fi
    done
done
