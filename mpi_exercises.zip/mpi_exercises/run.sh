#!/bin/bash

# Define the array of rectangle counts
num_rectangles=(10000000 50000000 100000000 500000000)

# Get the maximum number of cores on the machine
max_cores=$(nproc)
echo "Maximum number of cores: $max_cores"

# Function to find the next power of 2 greater than or equal to a number
next_power_of_2() {
  val=1
  while [ $val -lt $1 ]; do
    val=$(( $val * 2 ))
  done
  echo $val
}

# Loop over the number of processes using powers of 2
for (( num_procs=1; num_procs<=$max_cores; num_procs=$(next_power_of_2 $(($num_procs + 1)) ) )); do
  # Loop over the rectangle counts
  for num_steps in "${num_rectangles[@]}"; do
    echo "Running with $num_procs processes and $num_steps rectangles"
    # Execute the program
    mpirun -np $num_procs ./aux $num_steps
  done
done
